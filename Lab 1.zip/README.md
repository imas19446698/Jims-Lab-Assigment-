# Lab 1 – HospiManagementApp (Secure Patient & Staff Registration)

## Purpose

This project implements **Lab 1: Foundation & Patient Registration** for the
Hospital Management App. It focuses on:

- A clean Android project structure (UI, Data, Util layers).
- A validated **patient registration** workflow.
- A **Room** database with basic field-level encryption.
- Core **admin / staff** setup and simple session-based RBAC foundations.
- Validation logic with supporting unit tests.

The implementation is intentionally small but showcases **secure development
and deployment principles** that can be iterated on in future labs.

## High-Level Architecture

- `ui/` – Activities and layouts:
  - `MainActivity` – Landing screen + navigation + session status.
  - `PatientRegistrationActivity` – NHS patient registration form.
  - `AdminLoginActivity` – First-admin setup + admin login.
  - `AdminPortalActivity` – Staff registration (ADMIN / CLINICIAN / RECEPTION).

- `data/` – Persistence layer using Room:
  - `Patient` – Patient entity with encrypted sensitive fields.
  - `Staff` – Staff entity with roles and encrypted admin PIN.
  - `PatientDao`, `StaffDao` – DAOs encapsulating SQL queries.
  - `AppDatabase` – Room database singleton.

- `util/` – Cross-cutting helpers:
  - `SessionManager` – Simple SharedPreferences-based session store.
  - `NhsValidator` – NHS number validation using modulus 11 check.
  - `CryptoUtils` – Basic AES-based encryption helper (for demo only).

- `app/src/test/.../NhsValidatorTest` – JUnit tests for validation logic.

## Functional Specification Mapping

**Requirement:** Patient registration form capturing NHS number, full name,
DOB and contact details.  
**Implementation:**
- `PatientRegistrationActivity` layout (`activity_patient_registration.xml`)
  exposes fields for:
  - `NHS Number`
  - `Full Name`
  - `Date of Birth`
  - `Phone`
  - `Email`
- On save, an instance of `Patient` is created and written via `PatientDao`.

**Requirement:** Validate NHS number format.  
**Implementation:**
- `NhsValidator.isValid(String)`:
  - Strips whitespace.
  - Checks for exactly 10 digits.
  - Applies the official **modulus 11** checksum to ensure integrity.
- Used in `PatientRegistrationActivity.onSaveClicked` before any persistence.

**Requirement:** Securely store patient data in Room.  
**Implementation:**
- `Patient` entity stores encrypted fields:
  - `nhsNumberEnc`, `phoneEnc`, `emailEnc`.
- `CryptoUtils.encrypt()` is applied in the Activity *before* building the
  entity object.
- Plain text values are never written to the database.

**Requirement:** Basic error handling for invalid / incomplete data.  
**Implementation:**
- Mandatory field checks and NHS validation show `Toast` messages and
  abort the operation early.
- Encryption failure also aborts registration and informs the user.

**Requirement:** Room DB with basic encryption.  
**Implementation details:**
- `AppDatabase` defines the Room database.
- Field-level encryption is implemented in `CryptoUtils` using AES and
  applied manually in UI logic.
- This demonstrates the concept of protecting **data at rest** without
  requiring external libraries.
- A production-grade solution should use a full-database encryption
  provider (e.g. SQLCipher) and Android Keystore–protected keys.

**Requirement:** Accessibility & usability.  
**Implementation:**
- Layouts use clear labels and hints; input types are set for email, phone
  and dates.
- Forms are scrollable on small devices (via `ScrollView`).

**Requirement:** Validation logic supported by unit testing.  
**Implementation:**
- `NhsValidatorTest` (JUnit) validates:
  - Known valid NHS number.
  - Numbers that fail checksum.
  - Non-numeric input.
- Additional tests can be added to strengthen coverage.

## Security & Secure Development Considerations

1. **Defence in depth for patient data**
   - Encryption is applied at the field level prior to persistence.
   - DAO interfaces (`PatientDao`, `StaffDao`) centralise access and
     provide a clear audit surface for security reviews.

2. **Minimal session surface**
   - `SessionManager` stores **only** role and email in SharedPreferences,
     avoiding storage of high-sensitivity data.
   - `MainActivity` reads session data to display signed-in state and offers
     a single `Clear Session` control to simulate logout.

3. **RBAC foundations**
   - `Staff.Role` enum defines `ADMIN`, `CLINICIAN`, and `RECEPTION`.
   - Admin creation and login is gated through `AdminLoginActivity`.
   - Future labs can build on this to check role before showing or enabling
     sensitive operations (e.g. viewing clinical records).

4. **Input validation to prevent unsafe data**
   - NHS number validation prevents structurally invalid IDs from reaching
     the DB.
   - Android input types (`number`, `phone`, `textEmailAddress`) reduce
     malformed input and improve UX.

5. **Error handling**
   - All validation failures and crypto issues surface user-friendly
     messages while failing closed (the operation is cancelled).

6. **Limitations and next steps**
   - Static crypto key in `CryptoUtils` is **not** appropriate for
     production; it should be replaced by a key in Android Keystore.
   - No authentication throttling or lockout is implemented for PIN
     failures.
   - Network communication, logging and audit trails are outside the scope
     of this lab but would be required for a real deployment.

## Build & Run Instructions

1. Open the project folder (`HospiManagementApp`) in **Android Studio**.
2. Allow Gradle sync to complete.
3. Build and run on an emulator or device (API 24+).

## Usage Walkthrough

1. **First launch**
   - `MainActivity` shows `Welcome (not signed in)`.

2. **Create the first admin**
   - Tap **Admin Portal**.
   - If no ADMIN exists, the screen enters `Setup Mode`.
   - Enter admin email + PIN and tap **Create First Admin**.
   - Session is stored; you are redirected to `AdminPortalActivity`.

3. **Register staff**
   - In Admin Portal, enter staff name, email, choose role and optional PIN.
   - Tap **Register Staff Member** to persist to the `staff` table.

4. **Register a patient**
   - Navigate back to `MainActivity` and press **Patient Registration**.
   - Enter NHS number, full name, DOB, phone and email.
   - On **Register Patient**, validation + encryption occurs, then data is
     saved via Room.

5. **Clear session**
   - From `MainActivity`, press **Clear Session** to remove session data.

## Mapping Back to Lab Brief

- Clean architecture: folders match the `ui/`, `data/`, `util/` separation.
- Room entities and DAOs: `Patient`, `Staff`, `PatientDao`, `StaffDao`.
- Database: `AppDatabase` singleton (`hms_secure.db`).
- Patient registration UI and logic: `PatientRegistrationActivity`.
- Admin login and portal: `AdminLoginActivity`, `AdminPortalActivity`.
- Session management / RBAC foundations: `SessionManager`, `Staff.Role`.
- Validation + tests: `NhsValidator` + `NhsValidatorTest`.

This solution provides a solid, secure-by-design foundation for the
subsequent labs on appointments, biometrics and API integration.

package com.example.hospimanagementapp.data;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

/**
 * Central Room database definition.
 *
 * SECURITY NOTE:
 * - Field-level encryption is implemented in CryptoUtils and applied in the UI layer
 *   before objects are persisted using DAOs.
 * - For production systems a full-database encryption solution (e.g. SQLCipher for Android)
 *   with a user- or device-bound key should be used instead of the simplified approach here.
 */
@Database(entities = {Patient.class, Staff.class}, version = 1, exportSchema = false)
@TypeConverters({Staff.Converters.class})
public abstract class AppDatabase extends RoomDatabase {

    private static volatile AppDatabase INSTANCE;

    public abstract PatientDao patientDao();
    public abstract StaffDao staffDao();

    /**
     * Returns a singleton instance of the database.
     * Uses double-checked locking to be thread-safe and efficient.
     */
    public static AppDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                                    context.getApplicationContext(),
                                    AppDatabase.class,
                                    "hms_secure.db"
                            )
                            // In a real system, provide migration strategies instead of destructive migration.
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}

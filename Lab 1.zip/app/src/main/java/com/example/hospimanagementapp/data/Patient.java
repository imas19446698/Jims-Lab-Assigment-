package com.example.hospimanagementapp.data;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Patient entity representing a single patient record in the Room database.
 * Sensitive fields (NHS number, contact details) are encrypted at-rest using CryptoUtils
 * before being persisted to the database.
 */
@Entity(tableName = "patients")
public class Patient {

    @PrimaryKey(autoGenerate = true)
    public int id;                 // Surrogate primary key for internal use only

    @NonNull
    public String nhsNumberEnc;    // Encrypted NHS number (ciphertext, never store plain text)

    public String name;            // Patient full name (not encrypted for demo simplicity)

    public String dob;             // Date of birth; stored as ISO-8601 string (yyyy-MM-dd)

    public String phoneEnc;        // Encrypted contact phone number

    public String emailEnc;        // Encrypted contact email address

    // Convenience constructor used by the application (expects encrypted fields).
    public Patient(@NonNull String nhsNumberEnc,
                   String name,
                   String dob,
                   String phoneEnc,
                   String emailEnc) {
        this.nhsNumberEnc = nhsNumberEnc;
        this.name = name;
        this.dob = dob;
        this.phoneEnc = phoneEnc;
        this.emailEnc = emailEnc;
    }
}

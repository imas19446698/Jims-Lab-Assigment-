package com.example.hospimanagementapp.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

/**
 * DAO exposing strongly-typed queries for the Patient entity.
 * All access to the patient table must go through this API, which provides
 * a single place to monitor and harden database interactions.
 */
@Dao
public interface PatientDao {

    @Insert
    void insert(Patient patient);

    @Query("SELECT * FROM patients")
    List<Patient> getAll();
}

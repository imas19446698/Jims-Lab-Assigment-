package com.example.hospimanagementapp.data;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverter;

/**
 * Staff entity used to register admin / clinical / reception users.
 * Admins are used to protect access to the admin portal.
 */
@Entity(tableName = "staff")
public class Staff {

    /** Simple enum representing staff roles for RBAC (role-based access control). */
    public enum Role {
        ADMIN,
        CLINICIAN,
        RECEPTION
    }

    @PrimaryKey(autoGenerate = true)
    public long id;

    public String fullName;

    @NonNull
    public String email;           // Used as the login identifier

    @NonNull
    public Role role;              // Role drives authorisation checks

    public String adminPinEnc;     // Encrypted PIN (never store raw PIN)

    public Staff(String fullName,
                 @NonNull String email,
                 @NonNull Role role,
                 String adminPinEnc) {
        this.fullName = fullName;
        this.email = email;
        this.role = role;
        this.adminPinEnc = adminPinEnc;
    }

    /** Type converters so Room can persist the Role enum as text. */
    public static class Converters {
        @TypeConverter
        public static String fromRole(Role role) {
            return role == null ? null : role.name();
        }

        @TypeConverter
        public static Role toRole(String value) {
            return value == null ? null : Role.valueOf(value);
        }
    }
}

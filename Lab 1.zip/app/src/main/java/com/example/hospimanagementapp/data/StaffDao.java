package com.example.hospimanagementapp.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

/**
 * DAO responsible for all staff-related database access.  Encapsulating queries in
 * this interface helps avoid scattered SQL strings and supports security reviews.
 */
@Dao
public interface StaffDao {

    @Insert
    long insert(Staff staff);

    @Query("SELECT COUNT(*) FROM staff WHERE role = 'ADMIN'")
    int countAdmins();

    @Query("SELECT * FROM staff WHERE email = :email LIMIT 1")
    Staff findByEmail(String email);
}

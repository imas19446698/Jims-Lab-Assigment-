package com.example.hospimanagementapp.ui;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.hospimanagementapp.R;
import com.example.hospimanagementapp.data.AppDatabase;
import com.example.hospimanagementapp.data.Staff;
import com.example.hospimanagementapp.util.CryptoUtils;
import com.example.hospimanagementapp.util.SessionManager;

/**
 * Handles administrator login and first-admin-setup logic.
 *
 * Behaviour:
 *  - If there is no ADMIN yet, the screen shows "Setup Mode" and allows
 *    creating the first admin user.
 *  - If admins exist, it behaves as a login screen that checks the PIN.
 */
public class AdminLoginActivity extends AppCompatActivity {

    private TextView txtMode;
    private EditText edtEmail, edtPin;
    private Button btnLoginOrSetup;

    private boolean setupMode = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        txtMode = findViewById(R.id.txtMode);
        edtEmail = findViewById(R.id.edtAdminEmail);
        edtPin = findViewById(R.id.edtAdminPin);
        btnLoginOrSetup = findViewById(R.id.btnLoginOrSetup);

        btnLoginOrSetup.setOnClickListener(this::onLoginOrSetupClicked);

        // Determine mode asynchronously (DB query).
        AsyncTask.execute(() -> {
            AppDatabase db = AppDatabase.getInstance(getApplicationContext());
            int adminCount = db.staffDao().countAdmins();
            setupMode = adminCount == 0;
            runOnUiThread(this::updateUiForMode);
        });
    }

    private void updateUiForMode() {
        if (setupMode) {
            txtMode.setText("Admin Portal (Setup Mode)");
            btnLoginOrSetup.setText("Create First Admin");
        } else {
            txtMode.setText("Admin Portal Login");
            btnLoginOrSetup.setText("Log In");
        }
    }

    private void onLoginOrSetupClicked(View v) {
        String email = edtEmail.getText().toString().trim();
        String pin = edtPin.getText().toString().trim();

        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(pin)) {
            Toast.makeText(this, "Email and PIN are required.", Toast.LENGTH_LONG).show();
            return;
        }

        AsyncTask.execute(() -> {
            AppDatabase db = AppDatabase.getInstance(getApplicationContext());
            if (setupMode) {
                // First admin creation
                String pinEnc = CryptoUtils.encrypt(pin);
                Staff staff = new Staff(email, email, Staff.Role.ADMIN, pinEnc);
                db.staffDao().insert(staff);
                SessionManager.setCurrentUser(this, Staff.Role.ADMIN.name(), email);
                runOnUiThread(() -> {
                    Toast.makeText(this, "First admin account created.", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(this, AdminPortalActivity.class));
                    finish();
                });
            } else {
                // Normal login
                Staff existing = db.staffDao().findByEmail(email);
                if (existing == null || existing.adminPinEnc == null) {
                    runOnUiThread(() ->
                            Toast.makeText(this, "Account not found or no PIN set.", Toast.LENGTH_LONG).show());
                    return;
                }
                String storedPin = CryptoUtils.decrypt(existing.adminPinEnc);
                if (pin.equals(storedPin)) {
                    SessionManager.setCurrentUser(this, existing.role.name(), existing.email);
                    runOnUiThread(() -> {
                        Toast.makeText(this, "Login successful.", Toast.LENGTH_LONG).show();
                        startActivity(new Intent(this, AdminPortalActivity.class));
                        finish();
                    });
                } else {
                    runOnUiThread(() ->
                            Toast.makeText(this, "Invalid PIN.", Toast.LENGTH_LONG).show());
                }
            }
        });
    }
}

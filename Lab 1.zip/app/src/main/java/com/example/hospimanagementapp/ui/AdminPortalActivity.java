package com.example.hospimanagementapp.ui;

import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.hospimanagementapp.R;
import com.example.hospimanagementapp.data.AppDatabase;
import com.example.hospimanagementapp.data.Staff;
import com.example.hospimanagementapp.util.CryptoUtils;

/**
 * Simple admin portal that allows registering additional staff accounts.
 * This provides the basis for RBAC as later labs can restrict UI features
 * based on the staff role.
 */
public class AdminPortalActivity extends AppCompatActivity {

    private EditText edtStaffName, edtStaffEmail, edtStaffPin;
    private Spinner spnRole;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_portal);

        edtStaffName = findViewById(R.id.edtStaffName);
        edtStaffEmail = findViewById(R.id.edtStaffEmail);
        edtStaffPin = findViewById(R.id.edtStaffPin);
        spnRole = findViewById(R.id.spnRole);
        Button btnRegisterStaff = findViewById(R.id.btnRegisterStaff);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.staff_roles,
                android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnRole.setAdapter(adapter);

        btnRegisterStaff.setOnClickListener(this::onRegisterClicked);
    }

    private void onRegisterClicked(View v) {
        String name = edtStaffName.getText().toString().trim();
        String email = edtStaffEmail.getText().toString().trim();
        String pin = edtStaffPin.getText().toString().trim();
        String roleText = (String) spnRole.getSelectedItem();

        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(roleText)) {
            Toast.makeText(this, "Email and role are required.", Toast.LENGTH_LONG).show();
            return;
        }

        Staff.Role role = Staff.Role.valueOf(roleText);
        String pinEnc = TextUtils.isEmpty(pin) ? null : CryptoUtils.encrypt(pin);

        Staff staff = new Staff(name, email, role, pinEnc);

        AsyncTask.execute(() -> {
            AppDatabase db = AppDatabase.getInstance(getApplicationContext());
            db.staffDao().insert(staff);
            runOnUiThread(() ->
                    Toast.makeText(this, "Staff account created.", Toast.LENGTH_LONG).show());
        });
    }
}

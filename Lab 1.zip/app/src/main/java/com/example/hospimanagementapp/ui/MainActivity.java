package com.example.hospimanagementapp.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.hospimanagementapp.R;
import com.example.hospimanagementapp.util.SessionManager;

/**
 * Landing screen of the app.
 *
 * Shows:
 *  - current session status (signed in / not signed in)
 *  - navigation buttons to patient registration and admin portal
 *  - a "Clear Session" button that wipes SessionManager (simulating logout).
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView statusText = findViewById(R.id.txtStatus);
        Button btnPatientReg = findViewById(R.id.btnPatientRegistration);
        Button btnAdminPortal = findViewById(R.id.btnAdminPortal);
        Button btnClearSession = findViewById(R.id.btnClearSession);

        updateStatus(statusText);

        btnPatientReg.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, PatientRegistrationActivity.class)));

        btnAdminPortal.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, AdminLoginActivity.class)));

        btnClearSession.setOnClickListener(v -> {
            SessionManager.clear(MainActivity.this);
            updateStatus(statusText);
        });
    }

    private void updateStatus(TextView statusText) {
        String role = SessionManager.getCurrentRole(this);
        String email = SessionManager.getCurrentEmail(this);
        if (role == null) {
            statusText.setText("Welcome (not signed in)");
        } else {
            String msg = "Signed in: " + email + " (" + role + ")";
            statusText.setText(msg);
        }
    }
}

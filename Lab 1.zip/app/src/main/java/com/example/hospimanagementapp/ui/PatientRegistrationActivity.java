package com.example.hospimanagementapp.ui;

import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.hospimanagementapp.R;
import com.example.hospimanagementapp.data.AppDatabase;
import com.example.hospimanagementapp.data.Patient;
import com.example.hospimanagementapp.util.CryptoUtils;
import com.example.hospimanagementapp.util.NhsValidator;

/**
 * Screen that captures core patient registration details and persists
 * them to the Room database after validation + basic encryption.
 */
public class PatientRegistrationActivity extends AppCompatActivity {

    private EditText edtNhs, edtName, edtDob, edtPhone, edtEmail;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_registration);

        edtNhs = findViewById(R.id.edtNhsNumber);
        edtName = findViewById(R.id.edtFullName);
        edtDob = findViewById(R.id.edtDob);
        edtPhone = findViewById(R.id.edtPhone);
        edtEmail = findViewById(R.id.edtEmail);
        Button btnSave = findViewById(R.id.btnSavePatient);

        btnSave.setOnClickListener(this::onSaveClicked);
    }

    private void onSaveClicked(View v) {
        String nhs = edtNhs.getText().toString().trim();
        String name = edtName.getText().toString().trim();
        String dob = edtDob.getText().toString().trim();
        String phone = edtPhone.getText().toString().trim();
        String email = edtEmail.getText().toString().trim();

        // Basic mandatory field checks
        if (TextUtils.isEmpty(nhs) || TextUtils.isEmpty(name) || TextUtils.isEmpty(dob)) {
            Toast.makeText(this, "NHS number, name and DOB are required.", Toast.LENGTH_LONG).show();
            return;
        }

        // NHS number format validation
        if (!NhsValidator.isValid(nhs)) {
            Toast.makeText(this, "NHS number is invalid.", Toast.LENGTH_LONG).show();
            return;
        }

        // Encrypt sensitive fields before they leave the Activity.
        String nhsEnc = CryptoUtils.encrypt(nhs);
        String phoneEnc = CryptoUtils.encrypt(phone);
        String emailEnc = CryptoUtils.encrypt(email);

        if (nhsEnc == null) {
            Toast.makeText(this, "Encryption error - registration aborted.", Toast.LENGTH_LONG).show();
            return;
        }

        Patient patient = new Patient(nhsEnc, name, dob, phoneEnc, emailEnc);

        // Async insertion to avoid blocking the UI thread.
        AsyncTask.execute(() -> {
            AppDatabase db = AppDatabase.getInstance(getApplicationContext());
            db.patientDao().insert(patient);
            runOnUiThread(() ->
                    Toast.makeText(this, "Patient registered securely.", Toast.LENGTH_LONG).show()
            );
        });
    }
}

package com.example.hospimanagementapp.util;

import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

/**
 * Extremely small helper used to provide *basic* encryption for sensitive fields.
 *
 * WARNING: The implementation below is intentionally simple for teaching purposes.
 * In a real NHS system you must use a well-reviewed crypto library, protect
 * keys using hardware-backed keystores, rotate keys and follow NHS / NCSC guidance.
 */
public final class CryptoUtils {

    // Static key used only for the lab. Replace with a key stored in Android Keystore for real apps.
    private static final String SECRET = "CHANGE_ME_LAB_KEY";

    private CryptoUtils() {
    }

    private static SecretKeySpec getKey() throws GeneralSecurityException {
        // Derive a 128-bit AES key from the shared secret using SHA-256 (demo only).
        MessageDigest sha = MessageDigest.getInstance("SHA-256");
        byte[] key = sha.digest(SECRET.getBytes(StandardCharsets.UTF_8));
        byte[] shortKey = new byte[16];
        System.arraycopy(key, 0, shortKey, 0, 16);
        return new SecretKeySpec(shortKey, "AES");
    }

    public static String encrypt(String plainText) {
        if (plainText == null || plainText.isEmpty()) {
            return plainText;
        }
        try {
            SecretKeySpec keySpec = getKey();
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, keySpec);
            byte[] encrypted = cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));
            return Base64.encodeToString(encrypted, Base64.NO_WRAP);
        } catch (GeneralSecurityException e) {
            // In a real system you would log to a secure log store; here we fail closed by not returning plain text.
            return null;
        }
    }

    public static String decrypt(String cipherText) {
        if (cipherText == null || cipherText.isEmpty()) {
            return cipherText;
        }
        try {
            SecretKeySpec keySpec = getKey();
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, keySpec);
            byte[] decoded = Base64.decode(cipherText, Base64.NO_WRAP);
            byte[] decrypted = cipher.doFinal(decoded);
            return new String(decrypted, StandardCharsets.UTF_8);
        } catch (GeneralSecurityException e) {
            return null;
        }
    }
}

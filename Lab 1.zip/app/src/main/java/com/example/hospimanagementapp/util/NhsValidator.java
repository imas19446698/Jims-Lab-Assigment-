package com.example.hospimanagementapp.util;

/**
 * Utility class responsible solely for validating NHS numbers.
 *
 * Validation rules (simplified for this lab):
 *  - must be exactly 10 digits
 *  - must pass the NHS modulus 11 checksum.
 */
public final class NhsValidator {

    private NhsValidator() {
        // Utility class
    }

    /**
     * Returns true if the supplied NHS number is syntactically valid.
     */
    public static boolean isValid(String nhsNumber) {
        if (nhsNumber == null) {
            return false;
        }
        String digits = nhsNumber.replaceAll("\\s+", "");
        if (!digits.matches("\\d{10}")) {
            return false;
        }

        // Modulus 11 algorithm: first 9 digits weighted 10..2, mod 11, checksum rules
        int sum = 0;
        for (int i = 0; i < 9; i++) {
            int d = Character.getNumericValue(digits.charAt(i));
            int weight = 10 - i;
            sum += d * weight;
        }
        int remainder = sum % 11;
        int checkDigit = 11 - remainder;
        if (checkDigit == 11) {
            checkDigit = 0;
        }
        if (checkDigit == 10) {
            return false;
        }
        int lastDigit = Character.getNumericValue(digits.charAt(9));
        return checkDigit == lastDigit;
    }
}

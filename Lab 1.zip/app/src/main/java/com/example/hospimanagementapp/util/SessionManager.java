package com.example.hospimanagementapp.util;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Very small session helper built on top of SharedPreferences.
 * It remembers the currently signed-in staff user so the UI can tailor behaviour
 * (e.g. show the admin portal only to admin accounts).
 *
 * NOTE: No highly-sensitive data is stored here; only role + email identity.
 */
public final class SessionManager {

    private static final String PREFS = "hms_prefs";
    private static final String KEY_ROLE = "current_role";
    private static final String KEY_EMAIL = "current_email";

    private SessionManager() {
        // Utility class; prevent instantiation
    }

    public static void setCurrentUser(Context context, String role, String email) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        prefs.edit()
                .putString(KEY_ROLE, role)
                .putString(KEY_EMAIL, email)
                .apply();
    }

    public static String getCurrentRole(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_ROLE, null);
    }

    public static String getCurrentEmail(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_EMAIL, null);
    }

    public static void clear(Context context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .clear()
                .apply();
    }
}

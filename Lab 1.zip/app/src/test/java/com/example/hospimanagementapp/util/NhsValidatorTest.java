package com.example.hospimanagementapp.util;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Unit tests that exercise the NHS number validator with known-good and
 * known-bad examples.
 */
public class NhsValidatorTest {

    @Test
    public void validNumberPasses() {
        // 943 476 5919 is a common example of a valid NHS number.
        assertTrue(NhsValidator.isValid("9434765919"));
    }

    @Test
    public void invalidNumberFailsChecksum() {
        assertFalse(NhsValidator.isValid("1234567890"));
    }

    @Test
    public void nonDigitFails() {
        assertFalse(NhsValidator.isValid("ABCDE12345"));
    }
}

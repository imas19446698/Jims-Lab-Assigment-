# Lab 2 – Secure Appointments & Core Security Module

## Purpose

This sample Android module implements the key requirements from **Lab 2: Appointments & Core Security**:
- Appointment scheduling and conflict detection.
- Biometric authentication with secure fallback.
- Secure API communication using Retrofit.
- Basic Role‑Based Access Control (RBAC).
- Resilience against network failures.

The code is written in **Kotlin** and heavily commented to highlight secure development and deployment practices.

> This is a *teaching* implementation, focused on clarity and security concepts rather than production‑ready UI.

## High‑Level Architecture

- `ui` – Activities for login and appointment management.
- `model` – Appointment domain model.
- `data` – In‑memory repository for appointments + conflict detection.
- `network` – Retrofit service + secure HTTP client setup.
- `security` – Biometric auth wrapper + RBAC (roles & access checks).

### Main Flow

1. **LoginActivity**
   - Offers email + password login (fallback).
   - If device supports biometrics and the user has opted in, shows a biometric prompt.
   - On successful auth, navigates to `AppointmentListActivity`.

2. **AppointmentListActivity**
   - Fetches “today’s” appointments from a repository/API.
   - Allows filtering by clinic/location.
   - Allows the user to:
     - Book a new appointment.
     - Reschedule an existing appointment.
   - Performs **conflict detection** (no overlapping appointments for the same patient and time slot).

3. **Security Components**
   - `BiometricAuthManager`
     - Wraps `BiometricPrompt` and enforces secure configuration.
     - Uses explicit, minimal error messages to avoid information leakage.
   - `AccessManager`
     - Centralised RBAC checks based on `UserRole`.
   - `RetrofitClient`
     - Enforces HTTPS.
     - Configured for secure timeouts and basic TLS best practices.
     - Placeholder for cert pinning / auth headers (commented where they would go).

## Files & Responsibilities

- `model/Appointment.kt`
  - Data class for appointments.
  - Includes helper methods for conflict detection.

- `data/AppointmentRepository.kt`
  - In‑memory appointment store (for lab/demo purposes).
  - Implements:
    - `getAppointmentsForToday()`
    - `filterByClinic()`
    - `bookAppointment()` with conflict checks.
    - `rescheduleAppointment()` with conflict checks.

- `security/UserRole.kt`
  - Enum describing roles (PATIENT, CLINIC_ADMIN, SYSTEM_ADMIN).

- `security/AccessManager.kt`
  - Central helper for role‑based permission checks.
  - Used before any state‑changing operation to enforce least‑privilege.

- `security/BiometricAuthManager.kt`
  - BiometricPrompt wrapper.
  - Handles secure fallback to password login.
  - Validates device capability and user enrollment.

- `network/ApiService.kt`
  - Retrofit interface for appointment endpoints:
    - `getTodayAppointments()`
    - `bookAppointment()`
    - `rescheduleAppointment()`
  - Uses `suspend` functions for safe calls with coroutines.

- `network/RetrofitClient.kt`
  - Builds a Retrofit instance with:
    - HTTPS base URL (mock/test URL).
    - OkHttp client with sane timeouts.
    - Placeholder for interceptors (logging in debug only, auth headers).

- `ui/LoginActivity.kt`
  - Handles:
    - Basic email/password validation.
    - Invoking biometric authentication when available.
    - Navigating to `AppointmentListActivity` after successful auth.

- `ui/AppointmentListActivity.kt`
  - Displays appointments in a simple `RecyclerView` (adapter omitted for brevity).
  - Provides high‑level interactions for:
    - Filtering by clinic/location.
    - Booking/rescheduling appointments via repository methods.
  - Demonstrates:
    - Handling Retrofit/network failures gracefully.
    - Showing user‑friendly error messages.

- `res/layout/activity_login.xml`
- `res/layout/activity_appointment_list.xml`
  - Minimal, accessible layouts for the two main screens.

- `AndroidManifest.xml`
  - Declares activities and required permissions (e.g. INTERNET).
  - Sets `LoginActivity` as the launcher.

## Secure Development Considerations

- **Biometric Best Practices**
  - Uses `BiometricPrompt` instead of deprecated APIs.
  - Avoids storing raw biometric data; relies on system‑level secure hardware.
  - Uses a clear but non‑revealing error channel to avoid leaking security details.

- **RBAC & Least Privilege**
  - All mutating operations (book/reschedule) go through `AccessManager`.
  - Roles can be extended without changing business logic.

- **Secure API Communication**
  - Enforces HTTPS in the base URL.
  - Placeholder for **certificate pinning** and **auth tokens** (to be configured in a real deployment).
  - Timeouts set to defensive defaults to resist simple DoS scenarios.

- **Error Handling & Reliability**
  - Network calls wrapped in `try/catch` with domain‑specific error messages.
  - UI displays friendly messages instead of raw exception text.
  - Repository keeps a local copy of appointments as a fallback for simple offline scenarios.

- **Static & Dynamic Testing (Guidance)**
  - Static:
    - Run Kotlin Lint/Detekt to identify insecure patterns (e.g. hard‑coded credentials).
    - Ensure no secrets/keys are committed in the code.
  - Dynamic:
    - Exercise login (biometric & fallback), booking, and rescheduling flows on an emulator/physical device.
    - Simulate network loss (Airplane mode) while booking/rescheduling to confirm graceful degradation.

## How To Use This Sample

1. Create a new **Empty Activity** Android project in Android Studio using Kotlin.
2. Copy the contents of:
   - `model`, `data`, `security`, `network`, `ui` packages
   - `res/layout` XML files
   - Manifest declarations
3. Adjust the `applicationId` and package names to match your project.
4. Replace the mock base URL in `RetrofitClient.kt` with your local/mock API endpoint.
5. Implement / plug in a real `RecyclerView` adapter if you want a full UI.

The code is intentionally compact and focused on demonstrating the secure architecture required by Lab 2. 

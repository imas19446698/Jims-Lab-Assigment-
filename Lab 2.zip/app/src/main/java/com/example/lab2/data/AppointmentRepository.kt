package com.example.lab2.data

import com.example.lab2.model.Appointment
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.util.UUID

/**
 * In‑memory repository used for Lab 2.
 *
 * Security notes:
 * - In a real deployment, this would delegate to a remote API + local DB.
 * - No sensitive info is cached here; only appointment metadata.
 */
class AppointmentRepository {

    // Simple in‑memory storage for demo purposes.
    private val appointments: MutableList<Appointment> = mutableListOf()

    init {
        seedDemoData()
    }

    private fun seedDemoData() {
        val today = LocalDate.now()
        val start = LocalDateTime.of(today, LocalTime.of(9, 0))
        val end = LocalDateTime.of(today, LocalTime.of(9, 30))
        appointments += Appointment(
            id = UUID.randomUUID().toString(),
            patientId = "patient-001",
            clinicId = "clinic-a",
            location = "Main Clinic",
            start = start,
            end = end
        )
    }

    fun getAppointmentsForToday(): List<Appointment> {
        val today = LocalDate.now()
        return appointments.filter { it.start.toLocalDate() == today }
    }

    fun filterByClinic(clinicId: String?): List<Appointment> {
        val todays = getAppointmentsForToday()
        return if (clinicId.isNullOrBlank()) todays
        else todays.filter { it.clinicId == clinicId }
    }

    /**
     * Books a new appointment if there is no time conflict.
     *
     * @throws IllegalStateException if the time slot is already taken.
     */
    fun bookAppointment(
        patientId: String,
        clinicId: String,
        location: String,
        start: LocalDateTime,
        end: LocalDateTime
    ): Appointment {
        val candidate = Appointment(
            id = UUID.randomUUID().toString(),
            patientId = patientId,
            clinicId = clinicId,
            location = location,
            start = start,
            end = end
        )

        ensureNoConflict(candidate, patientId)

        appointments += candidate
        return candidate
    }

    /**
     * Reschedules an existing appointment by ID.
     *
     * @throws NoSuchElementException if appointment is not found.
     * @throws IllegalStateException if new time slot conflicts with another appointment.
     */
    fun rescheduleAppointment(
        appointmentId: String,
        newStart: LocalDateTime,
        newEnd: LocalDateTime
    ): Appointment {
        val existing = appointments.firstOrNull { it.id == appointmentId }
            ?: throw NoSuchElementException("Appointment not found")

        val updated = existing.copy(start = newStart, end = newEnd)

        ensureNoConflict(updated, existing.patientId, ignoreId = appointmentId)

        appointments.remove(existing)
        appointments.add(updated)
        return updated
    }

    private fun ensureNoConflict(
        candidate: Appointment,
        patientId: String,
        ignoreId: String? = null
    ) {
        val conflicts = appointments.any { current ->
            current.patientId == patientId &&
                (ignoreId == null || current.id != ignoreId) &&
                current.conflictsWith(candidate)
        }
        if (conflicts) {
            // We throw a generic exception type with a descriptive but non‑sensitive message.
            throw IllegalStateException("Selected time slot is not available.")
        }
    }
}

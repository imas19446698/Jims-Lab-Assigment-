package com.example.lab2.model

import java.time.LocalDateTime

/**
 * Domain model representing an appointment in the system.
 *
 * Security notes:
 * - This object is intentionally small; it does not carry any sensitive credentials.
 * - Only non‑sensitive, business relevant fields are stored here.
 */
data class Appointment(
    val id: String,
    val patientId: String,
    val clinicId: String,
    val location: String,
    val start: LocalDateTime,
    val end: LocalDateTime
) {
    /**
     * Check whether this appointment overlaps with another one.
     * Used as part of conflict detection when booking/rescheduling.
     */
    fun conflictsWith(other: Appointment): Boolean {
        // Two intervals [start, end) overlap when each starts before the other ends.
        return start < other.end && other.start < end
    }
}

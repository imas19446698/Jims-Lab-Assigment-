package com.example.lab2.network

import com.example.lab2.model.Appointment
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path

/**
 * Retrofit API definition.
 *
 * For this lab, the implementation can be against a mock server (e.g. MockWebServer
 * in tests or a simple local JSON API). The important part is that all calls
 * go over HTTPS and are wrapped with appropriate error handling.
 */
interface ApiService {

    @GET("appointments/today")
    suspend fun getTodayAppointments(): List<Appointment>

    @POST("appointments")
    suspend fun bookAppointment(@Body appointment: Appointment): Appointment

    @PUT("appointments/{id}")
    suspend fun rescheduleAppointment(
        @Path("id") id: String,
        @Body appointment: Appointment
    ): Appointment
}

package com.example.lab2.network

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Builds a Retrofit client with a securely‑configured OkHttpClient.
 *
 * Security notes:
 * - Base URL uses HTTPS to protect data in transit.
 * - Timeouts are kept moderate to mitigate resource exhaustion.
 * - Interceptors for auth headers and certificate pinning should be configured
 *   before deployment to production.
 */
object RetrofitClient {

    // Replace this with your mock / staging API endpoint.
    private const val BASE_URL = "https://example‑mock‑api.local/"

    private val okHttpClient: OkHttpClient by lazy {
        val builder = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)

        // Example: attach an interceptor to add auth headers securely.
        // builder.addInterceptor { chain ->
        //     val token = secureTokenProvider.getToken() // NEVER hard‑code tokens.
        //     val newRequest = chain.request().newBuilder()
        //         .addHeader("Authorization", "Bearer $token")
        //         .build()
        //     chain.proceed(newRequest)
        // }

        // Example: certificate pinning would be configured here.

        builder.build()
    }

    val apiService: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}

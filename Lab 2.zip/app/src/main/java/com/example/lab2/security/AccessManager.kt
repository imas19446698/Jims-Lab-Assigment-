package com.example.lab2.security

/**
 * Centralised Role‑Based Access Control (RBAC) helper.
 *
 * All business operations that change system state should rely on this class to
 * enforce authorization rules. This reduces the risk of "forgotten" checks.
 */
object AccessManager {

    /**
     * Can the user view appointments?
     * For this lab, all authenticated roles are allowed.
     */
    fun canViewAppointments(role: UserRole): Boolean = when (role) {
        UserRole.PATIENT,
        UserRole.CLINIC_ADMIN,
        UserRole.SYSTEM_ADMIN -> true
    }

    /**
     * Can the user create or reschedule appointments?
     *
     * Patients may book for themselves, admins may manage for others.
     * For simplicity, we expose a boolean here; in a real app, we'd also pass the
     * target patient/clinic IDs to enforce finer‑grained checks.
     */
    fun canModifyAppointments(role: UserRole): Boolean = when (role) {
        UserRole.PATIENT -> true
        UserRole.CLINIC_ADMIN -> true
        UserRole.SYSTEM_ADMIN -> true
    }

    /**
     * Example for more restricted operation: deleting appointments.
     */
    fun canDeleteAppointments(role: UserRole): Boolean = when (role) {
        UserRole.PATIENT -> false
        UserRole.CLINIC_ADMIN -> true
        UserRole.SYSTEM_ADMIN -> true
    }
}

package com.example.lab2.security

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/**
 * Wrapper around BiometricPrompt to keep biometric logic and configuration
 * in a single, testable, and reviewable place.
 *
 * Security notes:
 * - We rely on the Android OS and hardware for secure biometric storage.
 * - We do NOT store raw biometric data, only the fact that the user opted in.
 * - We keep error messages generic to avoid leaking security‑sensitive details.
 */
class BiometricAuthManager(
    private val context: Context
) {

    interface Callback {
        fun onSuccess()
        fun onFailure(error: String)
    }

    fun isBiometricAvailable(): Boolean {
        val manager = BiometricManager.from(context)
        return manager.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG
        ) == BiometricManager.BIOMETRIC_SUCCESS
    }

    fun authenticate(activity: FragmentActivity, callback: Callback) {
        if (!isBiometricAvailable()) {
            callback.onFailure("Biometric authentication not available.")
            return
        }

        val executor = ContextCompat.getMainExecutor(context)
        val prompt = BiometricPrompt(
            activity,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    callback.onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    // We return a generic message; detailed OS messages are logged but not shown to the user.
                    callback.onFailure("Biometric authentication failed.")
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    callback.onFailure("Biometric authentication failed.")
                }
            }
        )

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Secure Login")
            .setSubtitle("Use your biometric credential to log in")
            // Device PIN/PATTERN/PASSWORD acts as a secure fallback.
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .setNegativeButtonText("Use password")
            .build()

        prompt.authenticate(promptInfo)
    }
}

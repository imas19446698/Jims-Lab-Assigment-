package com.example.lab2.security

/**
 * Basic RBAC roles for the application.
 *
 * Security notes:
 * - This can be extended as the system grows.
 * - Authorization checks should be centrally performed through AccessManager.
 */
enum class UserRole {
    PATIENT,
    CLINIC_ADMIN,
    SYSTEM_ADMIN
}

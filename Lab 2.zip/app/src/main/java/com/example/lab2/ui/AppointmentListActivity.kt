package com.example.lab2.ui

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.lab2.R
import com.example.lab2.data.AppointmentRepository
import com.example.lab2.security.AccessManager
import com.example.lab2.security.UserRole
import java.time.LocalDateTime
import java.time.LocalTime

/**
 * AppointmentListActivity shows a (simplified) list of today's appointments,
 * allows filtering by clinic, and demonstrates booking/rescheduling with
 * conflict detection and RBAC checks.
 *
 * UI is intentionally minimal; focus is on secure logic flow.
 */
class AppointmentListActivity : AppCompatActivity() {

    private val repository = AppointmentRepository()

    private lateinit var role: UserRole

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_appointment_list)

        role = intent.getStringExtra(EXTRA_ROLE)
            ?.let { UserRole.valueOf(it) }
            ?: UserRole.PATIENT

        val filterClinicInput: EditText = findViewById(R.id.editFilterClinic)
        val applyFilterButton: Button = findViewById(R.id.btnApplyFilter)
        val bookButton: Button = findViewById(R.id.btnBook)
        val rescheduleButton: Button = findViewById(R.id.btnReschedule)
        val appointmentsText: TextView = findViewById(R.id.textAppointments)

        fun refreshAppointments(clinicId: String? = null) {
            val list = repository.filterByClinic(clinicId)
            val text = if (list.isEmpty()) {
                "No appointments for today."
            } else {
                list.joinToString(separator = "\n") { a ->
                    "${a.start.toLocalTime()} - ${a.end.toLocalTime()} @ ${a.location} (clinic=${a.clinicId})"
                }
            }
            appointmentsText.text = text
        }

        refreshAppointments()

        applyFilterButton.setOnClickListener {
            val clinicId = filterClinicInput.text.toString().ifBlank { null }
            refreshAppointments(clinicId)
        }

        bookButton.setOnClickListener {
            if (!AccessManager.canModifyAppointments(role)) {
                Toast.makeText(this, "You are not allowed to book appointments.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            try {
                // For demo purposes we create a fixed slot. In a real UI these values come from user input.
                val start = LocalDateTime.now().withHour(10).withMinute(0)
                val end = start.plusMinutes(30)
                repository.bookAppointment(
                    patientId = "patient-001",
                    clinicId = "clinic-a",
                    location = "Main Clinic",
                    start = start,
                    end = end
                )
                Toast.makeText(this, "Appointment booked.", Toast.LENGTH_SHORT).show()
                refreshAppointments()
            } catch (ex: IllegalStateException) {
                // Domain error (conflict). We show a generic message and avoid leaking internal IDs.
                Toast.makeText(this, ex.message, Toast.LENGTH_SHORT).show()
            } catch (ex: Exception) {
                // Fallback for unexpected issues.
                Toast.makeText(this, "Could not book appointment. Please try again.", Toast.LENGTH_SHORT).show()
            }
        }

        rescheduleButton.setOnClickListener {
            if (!AccessManager.canModifyAppointments(role)) {
                Toast.makeText(this, "You are not allowed to reschedule appointments.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            try {
                val todays = repository.getAppointmentsForToday()
                if (todays.isEmpty()) {
                    Toast.makeText(this, "No appointments to reschedule.", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                val first = todays.first()
                val newStart = first.start.with(LocalTime.of(11, 0))
                val newEnd = newStart.plusMinutes(30)

                repository.rescheduleAppointment(first.id, newStart, newEnd)
                Toast.makeText(this, "Appointment rescheduled.", Toast.LENGTH_SHORT).show()
                refreshAppointments()
            } catch (ex: IllegalStateException) {
                Toast.makeText(this, ex.message, Toast.LENGTH_SHORT).show()
            } catch (ex: Exception) {
                Toast.makeText(this, "Could not reschedule appointment. Please try again.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    companion object {
        const val EXTRA_ROLE = "extra_role"
    }
}

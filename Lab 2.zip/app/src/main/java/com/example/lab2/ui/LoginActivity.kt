package com.example.lab2.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.lab2.R
import com.example.lab2.security.BiometricAuthManager
import com.example.lab2.security.UserRole

/**
 * LoginActivity demonstrates a secure login flow with:
 * - Biometric authentication (when available and enabled).
 * - Password fallback.
 *
 * For the purposes of this lab, password validation is intentionally simple.
 * In production, passwords must be verified against a server using a secure
 * authentication protocol (e.g. OAuth2 / OpenID Connect).
 */
class LoginActivity : AppCompatActivity() {

    private lateinit var biometricAuthManager: BiometricAuthManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        biometricAuthManager = BiometricAuthManager(this)

        val emailInput: EditText = findViewById(R.id.editEmail)
        val passwordInput: EditText = findViewById(R.id.editPassword)
        val loginButton: Button = findViewById(R.id.btnLogin)
        val biometricButton: Button = findViewById(R.id.btnBiometric)

        loginButton.setOnClickListener {
            val email = emailInput.text.toString()
            val password = passwordInput.text.toString()

            if (email.isBlank() || password.isBlank()) {
                Toast.makeText(this, "Please enter email and password.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // In a real app, this is where you'd call a secure backend for auth.
            // For the lab we assume the credentials are valid.
            onAuthenticated(UserRole.PATIENT)
        }

        biometricButton.setOnClickListener {
            if (!biometricAuthManager.isBiometricAvailable()) {
                Toast.makeText(this, "Biometric auth not available on this device.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            biometricAuthManager.authenticate(this, object : BiometricAuthManager.Callback {
                override fun onSuccess() {
                    onAuthenticated(UserRole.PATIENT)
                }

                override fun onFailure(error: String) {
                    Toast.makeText(this@LoginActivity, error, Toast.LENGTH_SHORT).show()
                }
            })
        }
    }

    private fun onAuthenticated(role: UserRole) {
        // In a real app, the role would be obtained from the server and stored securely (e.g. in encrypted prefs).
        val intent = Intent(this, AppointmentListActivity::class.java).apply {
            putExtra(AppointmentListActivity.EXTRA_ROLE, role.name)
        }
        startActivity(intent)
        finish()
    }
}

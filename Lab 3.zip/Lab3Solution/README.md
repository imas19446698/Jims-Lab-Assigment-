# Lab 3 – Clinical Records & Advanced Features

## 1. Purpose of the Module

This module extends the existing Hospital Management Android application (Labs 1–2) with
an Electronic Health Record (EHR) component. It adds:

- A **patient summary** screen that displays clinical information.
- A **vital signs recording** workflow.
- **Barcode-based patient identification** using wristbands.
- **Offline data capture and background synchronisation** of vitals using WorkManager.
- **Pagination** for handling large sets of vitals efficiently.
- Implementation choices that explicitly consider **secure development and deployment**.

All new classes/files are placed under the existing package:
`com.example.hospimanagmenetapp`.

> **Note:** The code is written to be easily dropped into the Lab 2 project. You may need
> to slightly adjust package names or Gradle configuration to match your own setup.

---

## 2. Functional Requirements Mapping

### 2.1 Patient Summary Interface

**Files involved**
- `feature/ehr/ui/PatientSummaryActivity.java`
- `res/layout/activity_patient_summary.xml`
- `data/entities/ClinicalRecord.java`
- `data/dao/ClinicalRecordDao.java`

**Behaviour**
- Receives a patient NHS number via `Intent` extra: `nhsNumber`.
- Loads the corresponding `ClinicalRecord` from Room on a background thread.
- Displays **problems**, **allergies**, and **medications** for that patient.
- Provides a button to open the **vitals recording** screen for the same patient.

**Security & privacy considerations**
- No logging of patient identifiers or PHI.
- UI only displays data that already exists in the local Room database.
- Activity uses a neutral header format: `"Patient NHS: <id>"`, avoiding names or other PHI.

---

### 2.2 Recording Vital Signs

**Files involved**
- `feature/ehr/ui/VitalsActivity.java`
- `res/layout/activity_vitals.xml`
- `data/entities/Vitals.java`
- `data/dao/VitalsDao.java`
- `data/AppDatabase.java`
- `feature/ehr/work/VitalsSyncWorker.java`

**Behaviour**
- `VitalsActivity` receives the `nhsNumber` for the patient.
- The clinician enters:
  - Temperature (°C)
  - Heart rate (bpm)
  - Systolic and diastolic blood pressure (mmHg)
- On **Save**:
  - Input is validated (simple but explicit validation with inline comments).
  - A `Vitals` entity is created with `synced = false` and persisted via `VitalsDao.insert`.
  - WorkManager is triggered to enqueue a `VitalsSyncWorker` job for background upload.
- A short, non-sensitive confirmation message is shown (e.g. “Vitals saved for offline sync”).

**Security & privacy considerations**
- No vitals values or identifiers are written to logs.
- Messages shown to the user are deliberately non-identifying.
- Input validation aims to reduce accidental data entry errors without rejecting edge cases
  (e.g. extreme values are allowed but highlighted with comments so further validation
  can be added centrally if required).
- All DB access is on a background thread to avoid ANR and to make denial-of-service
  via heavy UI operations less likely.

---

### 2.3 Barcode Scanning & Patient Matching

**Files involved**
- `feature/ehr/ui/BarcodeScannerActivity.java`

**Behaviour**
- Uses **ZXing Embedded** (`com.journeyapps:zxing-android-embedded`) to continuously scan barcodes.
- When a barcode is decoded:
  - Scanning is paused immediately to avoid processing the same code twice.
  - The decoded text is treated as an NHS number and passed to `PatientSummaryActivity`
    via an `Intent` extra `nhsNumber`.
  - The scanner activity finishes so the user ends up on the summary screen.

**Security & privacy considerations**
- No PHI is stored in logs or notifications; only the decoded barcode value is held in memory
  long enough to start the next activity.
- CAMERA permission is requested via the manifest only. Runtime handling can be added per
  app policy (e.g. using the new permission APIs or a wrapper library).

---

### 2.4 Offline Synchronisation

**Files involved**
- `data/entities/Vitals.java` (field: `boolean synced`)
- `data/dao/VitalsDao.java` (methods: `getPending`, `markSynced`)
- `feature/ehr/work/VitalsSyncWorker.java`

**Behaviour**
- Every `Vitals` record is created with `synced = false`.
- `VitalsDao.getPending()` returns all unsynced records.
- `VitalsSyncWorker`:
  - Runs in the background (scheduled via WorkManager).
  - Fetches all pending vitals.
  - Simulates an upload to a remote server (this can be replaced with a real API call).
  - Marks a record as `synced = true` if the simulated upload succeeds.
- WorkManager is invoked from `VitalsActivity` after new vitals are saved, but it can also
  be set as a **periodic** worker at the Application level.

**Security & privacy considerations**
- No PHI is written to logs during synchronisation.
- If a real network upload is implemented, HTTPS **must** be used, with certificate
  validation and appropriate authentication.
- Worker is idempotent; if the app is killed or the device is offline, WorkManager
  will re-run the job when conditions permit, reducing risk of data loss.

---

### 2.5 Pagination & Performance

**Files involved**
- `data/dao/VitalsDao.java` (method `getLatestForPatientPaged`)
- `feature/ehr/ui/VitalsActivity.java` (manual pagination of history list)

**Behaviour**
- `VitalsDao` exposes a query with `LIMIT` and `OFFSET` so that history is loaded in
  small pages instead of as one big list.
- `VitalsActivity` demonstrates a manual “Load more” approach for vitals history:
  - Initially loads the most recent N entries (e.g. 20).
  - A “Load more history” button increases the offset and appends additional records.
- This satisfies the requirement for pagination while keeping the implementation
  dependency-free and Java-friendly. The provided Paging 3 dependency can be used
  to upgrade this to a fully reactive paged list if desired.

**Security & privacy considerations**
- Pagination only affects performance; it does not change what data is stored.
- No PHI is exposed beyond what the authenticated user can already see in the UI.

---

## 3. Non‑Functional Requirements Mapping

### 3.1 Reliable Offline Synchronisation

- Uses **WorkManager** (`androidx.work:work-runtime`) which is designed for deferrable,
  guaranteed background work.
- Work is retried automatically if it fails (via `Result.retry()` if implemented).
- The sample worker returns `Result.success()` for simulated uploads but is documented
  with comments to indicate where real error handling would go.

### 3.2 No PHI in Logs or Notifications

- The code **avoids** logging PHI altogether.
- Where comments mention logging, they explicitly warn **not** to log identifiers,
  vitals, or other sensitive data.
- Any user-facing feedback is deliberately generic (e.g. “Vitals saved locally” instead
  of “Vitals for patient X saved”).

### 3.3 Accessibility Enhancements

- Basic content descriptions and hints are added in the XML layouts.
- The code uses annotations from `androidx.annotation` (e.g. `@NonNull`) to make
  intent clearer and reduce null-related defects that cause crashes and impact users.

---

## 4. Build & Integration Notes

### 4.1 Gradle Dependencies (Add to `app/build.gradle`)

```gradle
dependencies {
    // Paging (ready for future use)
    implementation "androidx.paging:paging-runtime:3.3.2"

    // WorkManager (offline queue)
    implementation "androidx.work:work-runtime:2.9.1"

    // Barcode scanning (ZXing)
    implementation "com.journeyapps:zxing-android-embedded:4.3.0"
    implementation "com.google.zxing:core:3.5.3"

    // Accessibility / annotations
    implementation "androidx.annotation:annotation:1.9.1"
}
```

### 4.2 Manifest Entries (Minimal)

```xml
<manifest ...>
    <uses-permission android:name="android.permission.CAMERA" />

    <application ...>
        <activity android:name=".feature.ehr.ui.PatientSummaryActivity" />
        <activity android:name=".feature.ehr.ui.VitalsActivity" />
        <activity android:name=".feature.ehr.ui.BarcodeScannerActivity" />
    </application>
</manifest>
```

You may add orientation, labels, and theme attributes to suit your app.

---

## 5. Logic Overview (Step-by-Step Flow)

1. **Clinician scans barcode on patient wristband**
   - `BarcodeScannerActivity` decodes NHS number and opens `PatientSummaryActivity`.

2. **Clinician reviews patient summary**
   - `PatientSummaryActivity` loads `ClinicalRecord` from Room using NHS number.
   - Problems, allergies, and medications are displayed.
   - Clinician taps **Record Vitals**.

3. **Clinician records vitals**
   - `VitalsActivity` shows a form for temperature, heart rate, and blood pressure.
   - On **Save**:
     - Input is validated.
     - A `Vitals` entity is persisted with `synced = false`.
     - WorkManager is enqueued to sync vitals later.

4. **Background synchronisation**
   - `VitalsSyncWorker` runs (immediately or later, depending on conditions).
   - All `synced = false` vitals are fetched and uploaded (simulated).
   - On success, each vital is marked `synced = true`.

5. **Viewing history with pagination**
   - `VitalsActivity` can load recent vitals in pages using `LIMIT`/`OFFSET`.
   - A “Load more history” button fetches older pages when needed.

---

## 6. Secure Development & Deployment Considerations

- **Data minimisation:** Only store what is needed for the clinical workflow
  (conditions, allergies, medications, vitals). No free‑text notes or identifiers beyond
  the NHS number are persisted by this module.
- **Local storage:** Room database is used as the local store. For a production system,
  you should enable **full‑disk encryption** and consider additional application-level
  encryption for especially sensitive fields.
- **Transport security:** Any real network synchronisation must use TLS (HTTPS) with
  certificate pinning or at least strict hostname verification.
- **Error handling:** Worker is structured to support retries; comments indicate where
  to implement robust handling for network failures, 4xx/5xx responses, and timeouts.
- **Least privilege:** Only CAMERA permission is requested explicitly for the scanner.
- **Logging & monitoring:** Code avoids logging PHI by design; if logging is added,
  unit tests or lint rules should enforce that no PHI is logged or shown in notifications.
- **Testing:** The module is structured so that DAOs and entities can be tested
  independently with an in‑memory Room database.

---

## 7. Included Screenshot Mockups

The `screenshots/` folder contains simple mock screenshots to illustrate:

1. **`patient_summary.png`** – Patient summary with problems, allergies, medications, and
   a button to record vitals.
2. **`vitals_form.png`** – Vitals entry form (temperature, heart rate, blood pressure).
3. **`barcode_scan.png`** – Barcode scanner preview screen.

These are representative mockups to demonstrate the intended UI flow and can be
replaced with real emulator/device screenshots from your implementation.

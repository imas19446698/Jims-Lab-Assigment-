package com.example.hospimanagmenetapp.data;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.hospimanagmenetapp.data.dao.ClinicalRecordDao;
import com.example.hospimanagmenetapp.data.dao.VitalsDao;
import com.example.hospimanagmenetapp.data.entities.ClinicalRecord;
import com.example.hospimanagmenetapp.data.entities.Vitals;
// Note: Patient, Staff, Appointment are assumed to be defined in Lab 2.

/**
 * Main Room database for the hospital management app.
 *
 * This version adds ClinicalRecord and Vitals entities for the EHR module.
 * exportSchema is set to false to avoid accidentally shipping schema files,
 * but in a real project you may want to version-control them securely.
 */
@Database(
        entities = {
                // Lab 2 entities (not included in this snippet):
                // Patient.class, Staff.class, Appointment.class,
                ClinicalRecord.class,
                Vitals.class
        },
        version = 3,
        exportSchema = false
)
public abstract class AppDatabase extends RoomDatabase {

    private static volatile AppDatabase INSTANCE;

    public abstract ClinicalRecordDao clinicalRecordDao();
    public abstract VitalsDao vitalsDao();

    /**
     * Thread-safe singleton accessor. Using the application context prevents
     * accidental leaks of Activity contexts.
     */
    public static AppDatabase getInstance(@NonNull Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                                    context.getApplicationContext(),
                                    AppDatabase.class,
                                    "hospital_db"
                            )
                            // In production, remove allowMainThreadQueries entirely.
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}

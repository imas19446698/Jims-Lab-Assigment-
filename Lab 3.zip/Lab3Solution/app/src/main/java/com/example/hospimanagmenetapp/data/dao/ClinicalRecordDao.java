package com.example.hospimanagmenetapp.data.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.hospimanagmenetapp.data.entities.ClinicalRecord;

/**
 * DAO for CRUD operations on ClinicalRecord.
 *
 * Access is always performed on a background thread from UI code to avoid
 * blocking the main thread and causing ANR issues.
 */
@Dao
public interface ClinicalRecordDao {

    /**
     * Returns a single clinical record for the given NHS number.
     * LIMIT 1 is used to protect against unexpected duplicates.
     */
    @Query("SELECT * FROM clinical_records WHERE patientNhs=:nhs LIMIT 1")
    ClinicalRecord findByPatient(String nhs);

    /**
     * Insert or update a clinical record. Existing records with the same NHS
     * identifier are replaced to keep the latest information.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void upsert(ClinicalRecord record);
}

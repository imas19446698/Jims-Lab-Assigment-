package com.example.hospimanagmenetapp.data.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.hospimanagmenetapp.data.entities.Vitals;

import java.util.List;

/**
 * DAO for Vitals entity.
 *
 * Contains methods to support offline synchronisation and simple manual
 * pagination for browsing historical vitals without loading everything
 * into memory at once.
 */
@Dao
public interface VitalsDao {

    /**
     * Returns all vitals that have not yet been synchronised.
     * Used by the background worker.
     */
    @Query("SELECT * FROM vitals WHERE synced = 0")
    List<Vitals> getPending();

    /**
     * Inserts a new vitals record.
     *
     * @return the generated primary key.
     */
    @Insert
    long insert(Vitals v);

    /**
     * Marks a record as synchronised after a successful upload.
     */
    @Query("UPDATE vitals SET synced = 1 WHERE id = :id")
    void markSynced(long id);

    /**
     * Manual pagination: fetches the latest vitals for a given patient
     * using LIMIT/OFFSET. This avoids loading all history at once.
     */
    @Query("SELECT * FROM vitals WHERE patientNhs = :nhs ORDER BY timestamp DESC LIMIT :limit OFFSET :offset")
    List<Vitals> getLatestForPatientPaged(String nhs, int limit, int offset);
}

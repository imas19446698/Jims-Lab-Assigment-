package com.example.hospimanagmenetapp.data.entities;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * ClinicalRecord stores high-level clinical information for a patient.
 *
 * NOTE: This table is deliberately small and focused to limit stored PHI.
 *       Only the NHS identifier is stored here, not names or addresses.
 */
@Entity(tableName = "clinical_records")
public class ClinicalRecord {

    @PrimaryKey(autoGenerate = true)
    public long id;

    /**
     * NHS number is used as a pseudo-identifier to link to Patient/Vitals.
     * In a real system this should be validated and possibly encrypted at rest.
     */
    @NonNull
    public String patientNhs;

    /** Comma-separated or structured description of allergies. */
    public String allergies;

    /** Comma-separated or structured list of current medications. */
    public String medications;

    /** High-level list of active problems/diagnoses. */
    public String problems;

    /** Last update time in epoch millis (for audit/sync purposes). */
    public long updatedAt;
}

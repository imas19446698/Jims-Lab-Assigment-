package com.example.hospimanagmenetapp.data.entities;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Vitals entity represents a single vital signs observation for a patient.
 * Each record can be synchronised to a backend server and is marked via the
 * {@code synced} flag for offline/online workflows.
 */
@Entity(tableName = "vitals")
public class Vitals {

    @PrimaryKey(autoGenerate = true)
    public long id;

    /** NHS number linking the vitals to the patient. */
    @NonNull
    public String patientNhs;

    /** Body temperature in degrees Celsius. */
    public float temperature;

    /** Heart rate in beats per minute. */
    public int heartRate;

    /** Systolic blood pressure in mmHg. */
    public int systolic;

    /** Diastolic blood pressure in mmHg. */
    public int diastolic;

    /** Timestamp of measurement in epoch millis. */
    public long timestamp;

    /**
     * Synchronisation flag.
     * false = pending upload (stored only locally).
     * true  = successfully uploaded to the remote EHR server.
     */
    public boolean synced;
}

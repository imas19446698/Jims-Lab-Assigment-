package com.example.hospimanagmenetapp.feature.ehr.ui;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.Result;
import com.journeyapps.barcodescanner.BarcodeCallback;
import com.journeyapps.barcodescanner.DecoratedBarcodeView;

/**
 * Simple barcode scanner activity that uses ZXing's DecoratedBarcodeView to
 * continuously scan wristband barcodes and launch the patient summary screen.
 *
 * SECURITY NOTE:
 *  - We do not log the scanned result.
 *  - The decoded value is only used in-memory to route to the next screen.
 */
public class BarcodeScannerActivity extends AppCompatActivity {

    private DecoratedBarcodeView barcodeView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        barcodeView = new DecoratedBarcodeView(this);
        barcodeView.setStatusText("Align the patient wristband barcode within the frame.");
        setContentView(barcodeView);

        barcodeView.decodeContinuous(new BarcodeCallback() {
            @Override
            public void barcodeResult(Result result) {
                // Pause immediately to prevent duplicate reads.
                barcodeView.pause();

                String nhsNumber = result.getText();

                Intent i = new Intent(BarcodeScannerActivity.this, PatientSummaryActivity.class);
                i.putExtra("nhsNumber", nhsNumber);
                startActivity(i);
                finish();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        barcodeView.resume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        barcodeView.pause();
    }
}

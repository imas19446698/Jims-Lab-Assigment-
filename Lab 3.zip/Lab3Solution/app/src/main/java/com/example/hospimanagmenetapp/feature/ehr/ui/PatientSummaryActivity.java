package com.example.hospimanagmenetapp.feature.ehr.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.hospimanagmenetapp.R;
import com.example.hospimanagmenetapp.data.AppDatabase;
import com.example.hospimanagmenetapp.data.entities.ClinicalRecord;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * PatientSummaryActivity shows a concise clinical summary for a patient,
 * including problems, allergies, and medications. It also provides a
 * navigation entry point into the vitals recording workflow.
 */
public class PatientSummaryActivity extends AppCompatActivity {

    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_summary);

        TextView tvHeader = findViewById(R.id.tvPatientHeader);
        TextView tvProblems = findViewById(R.id.tvProblems);
        TextView tvAllergies = findViewById(R.id.tvAllergies);
        TextView tvMedications = findViewById(R.id.tvMedications);
        Button btnVitals = findViewById(R.id.btnRecordVitals);

        // NHS number is treated as a pseudo-identifier; it should come from a
        // trusted source such as the barcode scanner or appointment context.
        String nhs = getIntent().getStringExtra("nhsNumber");
        if (nhs == null) {
            nhs = "";
        }
        tvHeader.setText("Patient NHS: " + nhs);

        String finalNhs = nhs;
        executor.execute(() -> {
            ClinicalRecord record = AppDatabase.getInstance(getApplicationContext())
                    .clinicalRecordDao()
                    .findByPatient(finalNhs);

            runOnUiThread(() -> {
                if (record != null) {
                    tvProblems.setText("Problems: " + safe(record.problems));
                    tvAllergies.setText("Allergies: " + safe(record.allergies));
                    tvMedications.setText("Medications: " + safe(record.medications));
                } else {
                    tvProblems.setText("No clinical record found.");
                    tvAllergies.setVisibility(View.GONE);
                    tvMedications.setVisibility(View.GONE);
                }
            });
        });

        String finalNhs1 = nhs;
        btnVitals.setOnClickListener(v -> {
            Intent i = new Intent(this, VitalsActivity.class);
            i.putExtra("nhsNumber", finalNhs1);
            startActivity(i);
        });
    }

    private String safe(String value) {
        return value == null ? "" : value;
    }
}

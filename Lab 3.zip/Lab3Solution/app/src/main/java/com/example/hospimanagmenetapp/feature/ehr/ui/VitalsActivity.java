package com.example.hospimanagmenetapp.feature.ehr.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.hospimanagmenetapp.R;
import com.example.hospimanagmenetapp.data.AppDatabase;
import com.example.hospimanagmenetapp.data.entities.Vitals;
import com.example.hospimanagmenetapp.feature.ehr.work.VitalsSyncWorker;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * VitalsActivity allows a clinician to enter a single set of vital signs
 * for a given patient and view a paginated history of previous entries.
 *
 * All DB operations are performed off the main thread.
 */
public class VitalsActivity extends AppCompatActivity {

    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private EditText etTemp;
    private EditText etHeartRate;
    private EditText etSystolic;
    private EditText etDiastolic;
    private LinearLayout historyContainer;
    private Button btnLoadMore;

    private String nhsNumber;
    private int currentOffset = 0;
    private static final int PAGE_SIZE = 20;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vitals);

        nhsNumber = getIntent().getStringExtra("nhsNumber");

        etTemp = findViewById(R.id.etTemperature);
        etHeartRate = findViewById(R.id.etHeartRate);
        etSystolic = findViewById(R.id.etSystolic);
        etDiastolic = findViewById(R.id.etDiastolic);
        Button btnSave = findViewById(R.id.btnSaveVitals);
        historyContainer = findViewById(R.id.vitalsHistoryContainer);
        btnLoadMore = findViewById(R.id.btnLoadMoreHistory);

        btnSave.setOnClickListener(v -> saveVitals());
        btnLoadMore.setOnClickListener(v -> loadNextPage());

        // Load first page of history on start.
        loadNextPage();
    }

    private void saveVitals() {
        String tempStr = etTemp.getText().toString().trim();
        String hrStr = etHeartRate.getText().toString().trim();
        String sysStr = etSystolic.getText().toString().trim();
        String diaStr = etDiastolic.getText().toString().trim();

        if (TextUtils.isEmpty(tempStr) || TextUtils.isEmpty(hrStr)
                || TextUtils.isEmpty(sysStr) || TextUtils.isEmpty(diaStr)) {
            Toast.makeText(this, "Please fill in all fields.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            float temp = Float.parseFloat(tempStr);
            int hr = Integer.parseInt(hrStr);
            int sys = Integer.parseInt(sysStr);
            int dia = Integer.parseInt(diaStr);

            // Basic sanity checks. In a real system you might centralise validation
            // and store ranges in configuration, not hard-code them.
            if (temp < 25f || temp > 45f) {
                Toast.makeText(this, "Temperature value looks unusual. Please confirm.", Toast.LENGTH_SHORT).show();
            }
            if (hr <= 0 || sys <= 0 || dia <= 0) {
                Toast.makeText(this, "Heart rate and blood pressure must be positive.", Toast.LENGTH_SHORT).show();
                return;
            }

            Vitals vitals = new Vitals();
            vitals.patientNhs = nhsNumber;
            vitals.temperature = temp;
            vitals.heartRate = hr;
            vitals.systolic = sys;
            vitals.diastolic = dia;
            vitals.timestamp = System.currentTimeMillis();
            vitals.synced = false;

            executor.execute(() -> {
                AppDatabase db = AppDatabase.getInstance(getApplicationContext());
                db.vitalsDao().insert(vitals);

                // Enqueue a one-time sync. Constraints (e.g., require network)
                // can be added in a real deployment.
                OneTimeWorkRequest request =
                        new OneTimeWorkRequest.Builder(VitalsSyncWorker.class).build();
                WorkManager.getInstance(getApplicationContext()).enqueue(request);

                runOnUiThread(() -> {
                    Toast.makeText(this, "Vitals saved for offline sync.", Toast.LENGTH_SHORT).show();
                    clearInputs();
                    // Refresh history from the top.
                    historyContainer.removeAllViews();
                    currentOffset = 0;
                    loadNextPage();
                });
            });
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter numeric values only.", Toast.LENGTH_SHORT).show();
        }
    }

    private void clearInputs() {
        etTemp.setText("");
        etHeartRate.setText("");
        etSystolic.setText("");
        etDiastolic.setText("");
    }

    private void loadNextPage() {
        btnLoadMore.setEnabled(false);
        executor.execute(() -> {
            List<Vitals> page = AppDatabase.getInstance(getApplicationContext())
                    .vitalsDao()
                    .getLatestForPatientPaged(nhsNumber, PAGE_SIZE, currentOffset);

            runOnUiThread(() -> {
                if (page.isEmpty() && currentOffset == 0) {
                    TextView tv = new TextView(this);
                    tv.setText("No vitals recorded yet.");
                    historyContainer.addView(tv);
                    btnLoadMore.setVisibility(View.GONE);
                } else {
                    appendHistory(page);
                    if (page.size() < PAGE_SIZE) {
                        // No more data to load.
                        btnLoadMore.setVisibility(View.GONE);
                    } else {
                        // More pages may exist.
                        btnLoadMore.setVisibility(View.VISIBLE);
                        btnLoadMore.setEnabled(true);
                        currentOffset += PAGE_SIZE;
                    }
                }
            });
        });
    }

    private void appendHistory(List<Vitals> items) {
        for (Vitals v : items) {
            TextView tv = new TextView(this);
            String status = v.synced ? "synced" : "pending";
            // Keep the displayed information minimal and clinical.
            tv.setText(
                    "Time: " + android.text.format.DateFormat.format("dd/MM HH:mm", v.timestamp) +
                            "  | Temp: " + v.temperature +
                            "  | HR: " + v.heartRate +
                            "  | BP: " + v.systolic + "/" + v.diastolic +
                            "  (" + status + ")"
            );
            historyContainer.addView(tv);
        }
    }
}

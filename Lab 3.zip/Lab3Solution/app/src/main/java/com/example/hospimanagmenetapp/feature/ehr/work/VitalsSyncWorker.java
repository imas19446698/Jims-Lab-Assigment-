package com.example.hospimanagmenetapp.feature.ehr.work;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.example.hospimanagmenetapp.data.AppDatabase;
import com.example.hospimanagmenetapp.data.entities.Vitals;

import java.util.List;

/**
 * VitalsSyncWorker is responsible for uploading locally stored vitals
 * to a remote server when network connectivity is available.
 *
 * For the purposes of this lab, the upload is simulated only. The code
 * is structured so that a real HTTPS API call can be dropped in later.
 */
public class VitalsSyncWorker extends Worker {

    public VitalsSyncWorker(@NonNull Context ctx, @NonNull WorkerParameters params) {
        super(ctx, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        AppDatabase db = AppDatabase.getInstance(getApplicationContext());
        List<Vitals> pending = db.vitalsDao().getPending();

        // In a real implementation, you would inject a secure API client here.
        for (Vitals v : pending) {
            try {
                // TODO: Replace this with a real HTTPS call to your backend.
                // IMPORTANT: Do not log PHI or identifiers when sending data.
                simulateUpload(v);

                // Mark as synchronised only after a successful upload.
                db.vitalsDao().markSynced(v.id);
            } catch (Exception e) {
                // If any upload fails, we can request a retry.
                return Result.retry();
            }
        }
        return Result.success();
    }

    /**
     * Simulates network latency and upload.
     * This method intentionally does nothing and throws no exceptions.
     */
    private void simulateUpload(Vitals vitals) throws InterruptedException {
        // Simulate a small delay to mimic network latency.
        Thread.sleep(100);
    }
}

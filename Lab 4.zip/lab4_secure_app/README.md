# Lab 4 – Enhanced Comprehensive Security Demo

## Purpose

This repository provides an **end‑to‑end, security‑focused sample application** for a healthcare‑style scenario.  
It is designed to demonstrate:

* Protection of patient data **in transit and at rest**.
* Defence against **SQL injection** and related input attacks.
* Basic **agentic security simulation** using an autonomous security agent.
* **Secure development and deployment** practices (production‑safe configuration, secrets management).
* **Static and dynamic testing** used to verify security behaviour.

Although the code is intentionally compact, it follows the same design principles you would apply to an
enterprise‑grade healthcare system.

---

## High‑Level Architecture

The project is a small Flask API exposing `/patients` and `/security` endpoints:

* **`app.py`** – Flask application, request handling, HTTP security headers.
* **`crypto_utils.py`** – Symmetric encryption using Fernet (AES + HMAC).
* **`security_agent.py`** – A lightweight agent that inspects traffic and records security alerts.
* **`tests/`** – Pytest suite for encryption, SQL injection defence, and agent behaviour.
* **`requirements.txt`** – Python runtime dependencies.

SQLite is used as the backing data store for simplicity; the same patterns apply to PostgreSQL, MySQL, etc.

---

## Functional Requirements Mapping

### 1. Asset Protection Measures

**At Rest**

* All patient attributes other than the record ID are **encrypted** before being written to the database.
* Table schema (`init_db` in `app.py`):

  ```sql
  CREATE TABLE patients (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name_ciphertext TEXT NOT NULL,
      dob_ciphertext TEXT NOT NULL,
      condition_ciphertext TEXT NOT NULL,
      contact_ciphertext TEXT NOT NULL
  );
  ```

* The helpers `encrypt_field()` and `decrypt_field()` in `crypto_utils.py` provide a single, consistent
  interface for encryption and decryption, reducing the risk of mistakes or misuse.

**In Transit**

* The Flask app is intended to run **behind an HTTPS‑terminating reverse proxy** (e.g. Nginx, API gateway).
* `set_security_headers()` in `app.py` configures:

  * `Strict-Transport-Security` (HSTS)
  * `Content-Security-Policy`
  * `X-Frame-Options`
  * `X-Content-Type-Options`
  * `Referrer-Policy`

  These headers form part of a defence‑in‑depth strategy to limit common web‑based attacks.

### 2. SQL Injection Defence

* All SQL statements use **parameterised queries** with `?` placeholders, e.g.:

  ```python
  db.execute(
      """INSERT INTO patients
             (name_ciphertext, dob_ciphertext, condition_ciphertext, contact_ciphertext)
             VALUES (?, ?, ?, ?)""",
      (encrypted_name, encrypted_dob, encrypted_condition, encrypted_contact),
  )
  ```

* Attack payloads are therefore treated as **data**, not executable SQL.
* `test_sql_injection_is_not_executed()` in `tests/test_app.py` validates that an attempted payload such as
  `Robert'); DROP TABLE patients;--` is stored harmlessly and does **not** drop the table.

### 3. Agentic Security Simulation

* `SecurityAgent` in `security_agent.py` analyses each request passed in via `app.before_request`:

  * Looks for simple SQLi markers (`' OR 1=1`, `UNION SELECT`, etc.) in the query string.
  * Looks for path traversal patterns (`../`, `%2e%2e/`) in the request path.
  * Flags obvious automated scanners via the `User-Agent` (e.g. `sqlmap`).

* Alerts are kept in memory and exposed via the **`/security/alerts`** endpoint.

* The **`/security/simulate`** endpoint calls `SecurityAgent.run_simulation()`, which injects a small set
  of synthetic SQL injection and path traversal events. This provides a safe way to exercise the agent
  without performing a real attack.

### 4. Data Compliance & Privacy

The code supports healthcare‑style requirements by:

* **Minimising PII exposure**: database records store only an integer ID in clear text.
* Releasing **only what is needed** to callers (ID + decrypted fields at the API boundary).
* Providing a clear separation between:
  * **transport protection** (TLS, security headers), and
  * **data‑at‑rest protection** (Fernet encryption).

In a production deployment you should additionally:

* Implement **role‑based access control** and fine‑grained authorisation checks.
* Configure **audit logging** for all accesses to patient records.
* Maintain a **data retention and deletion policy** aligned with local laws and organisational rules.

---

## Non‑Functional Requirements Mapping

### Production Safety

* `app.py` does **not** expose secrets or debugging output by default.
* Debug mode is controlled by the environment variable `LAB4_FLASK_DEBUG` and is **off by default**.
* The `__main__` block explicitly warns against using Flask’s development server in production and
  recommends a WSGI server behind a TLS‑terminating proxy.
* No sample credentials or real patient data are embedded in the repository.

### Healthcare Security Compliance (Conceptual)

While this is a teaching example and not a certified product, it aligns with common healthcare‑security
expectations, including:

* **Strong encryption** for data at rest (AES via Fernet).
* **Least privilege** and **data minimisation** for stored PII.
* **Input validation** and robust error handling to avoid leaking internal details.
* **Security monitoring** via the embedded agent, which could integrate with SIEM/SOC processes.

To adapt this for real‑world frameworks such as ISO 27001, NIST, NHS DSPT, HIPAA, or GDPR, you would:

* Integrate with an enterprise‑grade identity provider (OIDC/SAML).
* Use a managed database with transparent disk encryption.
* Move keys into a dedicated key‑management solution (HSM or cloud KMS).
* Document DPIAs, data flows, and access controls.

---

## Running the Application (Development Only)

### 1. Install Dependencies

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Set an Encryption Key (Recommended)

Generate a Fernet key:

```bash
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

Then export it:

```bash
export LAB4_ENC_KEY="<paste-generated-key-here>"
```

You may also override the database location:

```bash
export LAB4_DB_PATH="/secure/path/to/patients.db"
```

### 3. Run the Server

```bash
export LAB4_FLASK_DEBUG=true  # development only
python app.py
```

The API will listen on `http://127.0.0.1:5000`.

---

## Example API Usage

### Create a Patient

```bash
curl -X POST http://127.0.0.1:5000/patients \
  -H "Content-Type: application/json" \
  -d '{
        "name": "Alice Example",
        "dob": "1990-01-01",
        "condition": "Hypertension",
        "contact": "+44 1234 567890"
      }'
```

### List Patients

```bash
curl http://127.0.0.1:5000/patients
```

### Check Security Alerts

```bash
curl http://127.0.0.1:5000/security/alerts
```

### Run the Agentic Security Simulation

```bash
curl -X POST http://127.0.0.1:5000/security/simulate
```

---

## Testing & Verification

### Running the Test Suite

```bash
pytest -q
```

The test suite covers:

* **Encryption** round‑trip correctness and error handling (`tests/test_crypto.py`).
* **SQL injection defence** and encryption of stored records (`tests/test_app.py`).
* Behaviour of the **security agent and simulation** (`tests/test_security_agent.py`).

### Static vs Dynamic Testing

* The tests in `tests/` are primarily **dynamic** (runtime) tests.
* You are encouraged to add **static analysis** tools such as:

  * [`bandit`](https://bandit.readthedocs.io/) for Python security linting.
  * [`flake8`](https://flake8.pycqa.org/) for style and simple bug detection.

  Example (optional) commands:

  ```bash
  pip install bandit flake8
  bandit -r .
  flake8 .
  ```

Documenting the results of these tools – alongside the pytest output – will provide the
“comprehensive security test suite” and verification evidence required by the lab.

---

## Secure Deployment Considerations

When moving from the lab environment to production, follow these guidelines:

1. **Use HTTPS Everywhere**

   * Terminate TLS at a reverse proxy (e.g. Nginx, Envoy, API gateway).
   * Ensure HSTS is enabled for the public hostname.
   * Disable insecure cipher suites and enforce modern TLS versions.

2. **Harden the Runtime**

   * Run the application under a **non‑privileged service account**.
   * Apply OS‑level hardening and patching.
   * Use containerisation (Docker/Kubernetes) with read‑only file systems where possible.

3. **Protect Secrets**

   * Store `LAB4_ENC_KEY` and database credentials in a **secrets manager**.
   * Rotate keys according to your organisational key‑management policy.
   * Ensure secrets never appear in logs, stack traces, or client‑side code.

4. **Database Security**

   * Use a dedicated database user with **least privilege**.
   * Enforce encryption at rest and in transit at the database layer as well.
   * Enable database audit logging where supported.

5. **Monitoring & Incident Response**

   * Forward security agent alerts, application logs, and system logs to a central SIEM.
   * Define runbooks for investigating and responding to alerts.
   * Regularly rehearse incident‑response procedures.

6. **Compliance & Governance**

   * Map technical safeguards (encryption, access control, logging) to relevant
     regulatory requirements (e.g. GDPR Art. 32, HIPAA Security Rule).
   * Keep architectural diagrams, data‑flow maps, and DPIAs up to date.
   * Perform regular risk assessments and penetration tests.

---

## Summary

This lab implementation demonstrates how secure coding, encryption, and basic agentic security
mechanisms can be combined into a cohesive, testable system. The patterns used here – parameterised
queries, centralised cryptography helpers, TLS + security headers, and automated security checks –
are all building blocks for **secure development and deployment** in real healthcare environments.

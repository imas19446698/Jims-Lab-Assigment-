import os
import sqlite3
from flask import Flask, request, jsonify, g
from werkzeug.exceptions import BadRequest

from crypto_utils import encrypt_field, decrypt_field, get_fernet
from security_agent import SecurityAgent

DB_PATH = os.getenv("LAB4_DB_PATH", os.path.join(os.path.dirname(__file__), "patients.db"))

app = Flask(__name__)

# Instantiate a simple autonomous / semi‑autonomous security agent
security_agent = SecurityAgent()

def get_db():
    """Return a per‑request SQLite connection.

    Using a short‑lived connection per request simplifies reasoning about
    lifecycle and avoids connection sharing across threads.
    """
    if "db" not in g:
        # check_same_thread=False allows use in Flask's threaded server,
        # but we still keep usage scoped per request through the g object.
        g.db = sqlite3.connect(DB_PATH, check_same_thread=False)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exc):
    """Close the DB connection at the end of the request."""
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    """Create the patients table if it does not exist.

    The schema stores only the patient identifier in clear text.
    All other sensitive attributes are encrypted at rest using Fernet.
    """
    db = get_db()
    db.execute(
        """CREATE TABLE IF NOT EXISTS patients (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name_ciphertext TEXT NOT NULL,
                dob_ciphertext TEXT NOT NULL,
                condition_ciphertext TEXT NOT NULL,
                contact_ciphertext TEXT NOT NULL
            )"""
    )
    db.commit()


@app.before_request
def apply_security_controls():
    """Run lightweight security checks before each request.

    * Initialise database lazily.
    * Pass request metadata to the autonomous security agent so it can
      inspect paths, query strings and basic headers for suspicious patterns.
    """
    init_db()

    # Hand off a subset of request context to the agent
    security_agent.inspect_request(
        ip=request.remote_addr,
        path=request.path,
        method=request.method,
        query_string=request.query_string.decode("utf-8", errors="ignore"),
        user_agent=str(request.user_agent),
    )


@app.after_request
def set_security_headers(response):
    """Apply standard HTTP security headers.

    These headers are part of the defence‑in‑depth strategy for secure
    deployment in production. They assume the application is served
    *behind* an HTTPS‑terminating reverse proxy or load balancer.
    """
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "no-referrer")
    # HSTS instructs browsers to always use HTTPS for this host
    response.headers.setdefault(
        "Strict-Transport-Security", "max-age=63072000; includeSubDomains; preload"
    )
    # Basic CSP – in a real deployment this would be tuned to the front‑end
    response.headers.setdefault(
        "Content-Security-Policy",
        "default-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
    )
    return response


def validate_patient_payload(data: dict) -> dict:
    """Validate and normalise incoming JSON for patient operations.

    This function performs *input validation* (checking for required
    fields, types and reasonable lengths) which is distinct from
    *output encoding* and *SQL parameterisation* handled elsewhere.
    """
    required_fields = ["name", "dob", "condition", "contact"]
    if not isinstance(data, dict):
        raise BadRequest("Invalid JSON body")

    for field in required_fields:
        if field not in data:
            raise BadRequest(f"Missing required field: {field}")
        if not isinstance(data[field], str):
            raise BadRequest(f"Field '{field}' must be a string")
        if not data[field].strip():
            raise BadRequest(f"Field '{field}' must not be empty")
        # simple length limit to mitigate abuse / oversized payloads
        if len(data[field]) > 256:
            raise BadRequest(f"Field '{field}' is too long")

    return {k: data[k].strip() for k in required_fields}


@app.route("/patients", methods=["POST"])
def create_patient():
    """Create a new patient record.

    The API accepts PII in clear text over TLS (transport security
    is provided by the reverse proxy / gateway). Before writing to
    disk we encrypt each field using Fernet (AES‑128 in CBC with HMAC).
    """
    payload = validate_patient_payload(request.get_json(silent=True))
    db = get_db()

    # Parameterised query prevents SQL injection. Using ? placeholders
    # ensures the sqlite3 driver performs proper escaping and type binding.
    db.execute(
        """INSERT INTO patients
               (name_ciphertext, dob_ciphertext, condition_ciphertext, contact_ciphertext)
               VALUES (?, ?, ?, ?)""",
        (
            encrypt_field(payload["name"]),
            encrypt_field(payload["dob"]),
            encrypt_field(payload["condition"]),
            encrypt_field(payload["contact"]),
        ),
    )
    db.commit()

    # Return minimal information to the client – the opaque identifier
    # can be used for subsequent lookups without leaking PII in logs.
    patient_id = db.execute("SELECT last_insert_rowid() as id").fetchone()["id"]
    return jsonify({"id": patient_id}), 201


@app.route("/patients", methods=["GET"])
def list_patients():
    """Return a minimally‑privileged view of patient data.

    This endpoint demonstrates decryption at the application boundary.
    In a real system you would likely implement role‑based access
    control and return only the subset of fields required for the caller.
    """
    db = get_db()
    rows = db.execute(
        """SELECT id, name_ciphertext, dob_ciphertext,
                          condition_ciphertext, contact_ciphertext
               FROM patients"""
    ).fetchall()

    patients = []
    for row in rows:
        patients.append(
            {
                "id": row["id"],
                "name": decrypt_field(row["name_ciphertext"]),
                "dob": decrypt_field(row["dob_ciphertext"]),
                "condition": decrypt_field(row["condition_ciphertext"]),
                "contact": decrypt_field(row["contact_ciphertext"]),
            }
        )
    return jsonify(patients), 200


@app.route("/security/alerts", methods=["GET"])
def get_security_alerts():
    """Expose aggregated alerts from the autonomous security agent.

    This provides a very small 'agentic security simulation' – the agent
    analyses incoming requests and records events that look suspicious.
    Security operations staff (or another automated component) could
    poll this endpoint and feed alerts into SIEM / SOAR tooling.
    """
    return jsonify(security_agent.get_alerts()), 200


@app.route("/security/simulate", methods=["POST"])
def simulate_threat():
    """Trigger the security agent's built‑in simulation.

    The simulation fabricates a series of request patterns that are
    known‑bad (e.g. attempted SQL injection, path traversal), allowing
    you to test detection logic without attacking the live system.
    """
    scenarios = security_agent.run_simulation()
    return jsonify({"simulated_scenarios": scenarios}), 200


if __name__ == "__main__":
    # IMPORTANT:
    #  * Do NOT use Flask's built‑in server in production.
    #  * Production deployments should run this app behind a WSGI server
    #    such as gunicorn or uWSGI, with TLS terminated at a reverse proxy.
    debug_flag = os.getenv("LAB4_FLASK_DEBUG", "false").lower() == "true"
    app.run(host="127.0.0.1", port=5000, debug=debug_flag)

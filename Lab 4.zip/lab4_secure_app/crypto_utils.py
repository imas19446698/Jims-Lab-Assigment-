import base64
import os
from typing import Optional

from cryptography.fernet import Fernet, InvalidToken

# Environment variable name holding the encryption key.
FERNET_ENV_VAR = "LAB4_ENC_KEY"


def _generate_key() -> bytes:
    """Generate a new Fernet key.

    In production, key generation would happen one‑off during
    provisioning. Keys should be stored in an HSM, vault or
    dedicated secrets‑management system, not in source control.
    """
    return Fernet.generate_key()


def get_fernet() -> Fernet:
    """Return a Fernet instance using a key from the environment.

    If no key is present we fall back to a *development* key that is
    derived from a hard‑coded seed. This is intentionally insecure and
    exists solely to make the lab self‑contained.

    Students should replace this behaviour in their own work with
    a secure key‑management process (for example: secrets manager,
    cloud KMS, or manual key rotation playbooks).
    """
    key: Optional[bytes] = None
    env_val = os.getenv(FERNET_ENV_VAR)

    if env_val:
        # Environment variable may be either a raw Fernet key or a
        # base64‑encoded value. We try both interpretations.
        try:
            key = env_val.encode("utf-8")
            # Validate by instantiating Fernet; if this fails we will
            # drop into the except block.
            Fernet(key)
        except Exception:
            try:
                key = base64.urlsafe_b64decode(env_val)
            except Exception as exc:  # pragma: no cover - defensive
                raise RuntimeError(
                    f"Invalid value for {FERNET_ENV_VAR}: {exc}"
                ) from exc
    else:  # pragma: no cover - deterministic fallback for the lab
        seed = b"lab4-development-key-not-for-production"
        key = base64.urlsafe_b64encode(seed.ljust(32, b"0"))

    return Fernet(key)


def encrypt_field(value: str) -> str:
    """Encrypt a single field, returning a URL‑safe string.

    The plaintext is encoded as UTF‑8 and encrypted using Fernet,
    which provides authenticated symmetric encryption (AES + HMAC).
    """
    if value is None:
        raise ValueError("value must not be None")

    f = get_fernet()
    token = f.encrypt(value.encode("utf-8"))
    return token.decode("utf-8")


def decrypt_field(ciphertext: str) -> str:
    """Decrypt a single field, returning the original plaintext.

    Invalid or tampered ciphertexts raise InvalidToken; for the purposes
    of this lab we convert that into a generic RuntimeError to avoid
    leaking implementation details to callers.
    """
    if ciphertext is None:
        raise ValueError("ciphertext must not be None")

    f = get_fernet()
    try:
        plaintext = f.decrypt(ciphertext.encode("utf-8"))
        return plaintext.decode("utf-8")
    except InvalidToken as exc:
        raise RuntimeError("Decryption failed; ciphertext may be corrupted") from exc

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List


@dataclass
class SecurityEvent:
    """Simple representation of a security‑relevant event."""

    timestamp: str
    ip: str
    path: str
    method: str
    details: str


@dataclass
class SecurityAgent:
    """A tiny agent that inspects traffic for suspicious patterns.

    The goal is to *simulate* how an automated or semi‑automated
    mechanism might detect and surface potential security issues.

    This is deliberately lightweight and does not attempt to be
    a full IDS/WAF – instead, it focuses on clarity and pedagogy.
    """

    alerts: List[SecurityEvent] = field(default_factory=list)

    # Very small pattern library – in a real agent this would be
    # configurable and much richer.
    SQLI_MARKERS = ["' OR 1=1", "--", "; DROP TABLE", "UNION SELECT"]
    PATH_TRAVERSAL_MARKERS = ["../", "..\\", "%2e%2e/"]

    def _record(self, ip: str, path: str, method: str, details: str) -> None:
        event = SecurityEvent(
            timestamp=datetime.utcnow().isoformat(timespec="seconds") + "Z",
            ip=ip or "unknown",
            path=path,
            method=method,
            details=details,
        )
        self.alerts.append(event)

    def inspect_request(
        self,
        ip: str,
        path: str,
        method: str,
        query_string: str,
        user_agent: str,
    ) -> None:
        """Inspect a single HTTP request for obviously bad patterns.

        The agent looks for:
        * primitive SQL injection signatures in the query string; and
        * attempts at path traversal in the URL path.

        Any findings are recorded in memory; in a real system they
        would be pushed to a centralised logging pipeline.
        """
        # Normalise for case‑insensitive matching
        q_lower = (query_string or "").lower()
        path_lower = (path or "").lower()

        for marker in self.SQLI_MARKERS:
            if marker.lower() in q_lower:
                self._record(
                    ip=ip,
                    path=path,
                    method=method,
                    details=f"Possible SQL injection attempt detected: marker '{marker}'",
                )
                break

        for marker in self.PATH_TRAVERSAL_MARKERS:
            if marker.lower() in path_lower:
                self._record(
                    ip=ip,
                    path=path,
                    method=method,
                    details=f"Possible path traversal attempt detected: marker '{marker}'",
                )
                break

        # Basic heuristic: unusual user agents can be interesting
        if user_agent and "sqlmap" in user_agent.lower():
            self._record(
                ip=ip,
                path=path,
                method=method,
                details="Automated scanning tool detected in User‑Agent header",
            )

    def get_alerts(self) -> List[Dict[str, str]]:
        """Return alerts as serialisable dicts suitable for JSON."""
        return [event.__dict__ for event in self.alerts]

    def run_simulation(self) -> List[Dict[str, str]]:
        """Inject a small number of synthetic events.

        This method is used by the /security/simulate endpoint to
        demonstrate detection logic without performing real attacks.
        """
        self.inspect_request(
            ip="192.0.2.10",
            path="/patients?name=' OR 1=1--",
            method="GET",
            query_string="name=' OR 1=1--",
            user_agent="curl/8.0 lab-simulation",
        )
        self.inspect_request(
            ip="198.51.100.25",
            path="/../../etc/passwd",
            method="GET",
            query_string="",
            user_agent="curl/8.0 lab-simulation",
        )
        return self.get_alerts()

import os
import sqlite3

import pytest

from app import app, DB_PATH, init_db
from crypto_utils import encrypt_field


@pytest.fixture(autouse=True)
def _clean_db(tmp_path, monkeypatch):
    """Use a temporary database for each test run.

    This ensures tests are isolated and do not leak data, mirroring
    good practice for dynamic security testing.
    """
    db_file = tmp_path / "test_patients.db"
    monkeypatch.setenv("LAB4_DB_PATH", str(db_file))

    # Re‑import the app module so it picks up the new DB path
    # NOTE: in a larger project we would structure imports differently
    # to avoid needing reloads, but this is adequate for the lab.
    import importlib
    import app as app_module

    importlib.reload(app_module)
    global app
    app = app_module.app  # type: ignore[assignment]

    with app.app_context():
        init_db()
    yield


@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as c:
        yield c


def _get_db_rows():
    conn = sqlite3.connect(os.getenv("LAB4_DB_PATH", DB_PATH))
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        "SELECT id, name_ciphertext, dob_ciphertext, condition_ciphertext, contact_ciphertext FROM patients"
    ).fetchall()
    conn.close()
    return rows


def test_create_patient_stores_encrypted_data(client):
    response = client.post(
        "/patients",
        json={
            "name": "Alice Example",
            "dob": "1990-01-01",
            "condition": "Hypertension",
            "contact": "+44 1234 567890",
        },
    )
    assert response.status_code == 201
    body = response.get_json()
    assert "id" in body

    rows = _get_db_rows()
    assert len(rows) == 1
    row = rows[0]

    # Ensure ciphertext fields do not contain the plaintext
    for col in [
        "name_ciphertext",
        "dob_ciphertext",
        "condition_ciphertext",
        "contact_ciphertext",
    ]:
        value = row[col]
        assert "Alice" not in value
        assert "Hypertension" not in value


def test_list_patients_returns_decrypted_data(client):
    # Insert a record directly using the encryption helper
    from crypto_utils import encrypt_field

    conn = sqlite3.connect(os.getenv("LAB4_DB_PATH", DB_PATH))
    conn.execute(
        """INSERT INTO patients
               (name_ciphertext, dob_ciphertext, condition_ciphertext, contact_ciphertext)
               VALUES (?, ?, ?, ?)""",
        (
            encrypt_field("Bob Example"),
            encrypt_field("1985-12-12"),
            encrypt_field("Asthma"),
            encrypt_field("+44 5555 555"),
        ),
    )
    conn.commit()
    conn.close()

    response = client.get("/patients")
    assert response.status_code == 200
    patients = response.get_json()
    assert isinstance(patients, list)
    assert len(patients) >= 1

    # At least one patient should be the record we inserted
    assert any(p["name"] == "Bob Example" for p in patients)


def test_sql_injection_is_not_executed(client):
    """Demonstrate that parameterised queries protect against SQL injection.

    This test attempts to inject SQL into the 'name' field. Because
    we use parameterised queries, the payload is treated as data and
    stored as such; the database schema remains intact.
    """
    malicious_name = "Robert'); DROP TABLE patients;--"
    response = client.post(
        "/patients",
        json={
            "name": malicious_name,
            "dob": "1990-01-01",
            "condition": "Hypertension",
            "contact": "+44 1234 567890",
        },
    )
    assert response.status_code == 201

    # Table should still exist and contain at least one row
    rows = _get_db_rows()
    assert len(rows) >= 1

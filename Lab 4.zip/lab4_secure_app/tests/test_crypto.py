import pytest

from crypto_utils import encrypt_field, decrypt_field


def test_encrypt_and_decrypt_round_trip():
    plaintext = "Sensitive test value"
    ciphertext = encrypt_field(plaintext)

    # Ciphertext should not be the same as the plaintext and should look like a token
    assert ciphertext != plaintext
    assert isinstance(ciphertext, str)
    assert len(ciphertext) > len(plaintext)

    decrypted = decrypt_field(ciphertext)
    assert decrypted == plaintext


def test_encrypt_rejects_none():
    with pytest.raises(ValueError):
        encrypt_field(None)  # type: ignore[arg-type]


def test_decrypt_rejects_none():
    with pytest.raises(ValueError):
        decrypt_field(None)  # type: ignore[arg-type]

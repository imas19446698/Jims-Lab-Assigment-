from security_agent import SecurityAgent


def test_agent_detects_sql_injection_in_query_string():
    agent = SecurityAgent()
    agent.inspect_request(
        ip="203.0.113.1",
        path="/patients",
        method="GET",
        query_string="name=' OR 1=1--",
        user_agent="curl/8.0",
    )
    alerts = agent.get_alerts()
    assert any("sql injection" in a["details"].lower() for a in alerts)


def test_agent_detects_path_traversal_in_path():
    agent = SecurityAgent()
    agent.inspect_request(
        ip="203.0.113.2",
        path="/../../etc/passwd",
        method="GET",
        query_string="",
        user_agent="curl/8.0",
    )
    alerts = agent.get_alerts()
    assert any("path traversal" in a["details"].lower() for a in alerts)


def test_simulation_populates_alerts():
    agent = SecurityAgent()
    scenarios = agent.run_simulation()
    assert len(scenarios) >= 2
